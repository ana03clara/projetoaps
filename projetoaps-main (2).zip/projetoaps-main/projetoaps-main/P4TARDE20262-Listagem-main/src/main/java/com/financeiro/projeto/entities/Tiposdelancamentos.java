package com.financeiro.projeto.entities;

public enum Tiposdelancamentos {
    RECEITA,
    DESPESA
}
