package com.financeiro.projeto.entities;

import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table
public class TipoLancamento {

    //TODO [Reverse Engineering] generate columns from DB
}